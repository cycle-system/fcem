# fcem
Fuzzy Comprehensive Evaluation Methodology
